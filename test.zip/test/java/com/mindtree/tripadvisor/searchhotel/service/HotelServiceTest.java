package com.mindtree.tripadvisor.searchhotel.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.tripadvisor.searchhotel.entity.Hotel;
import com.mindtree.tripadvisor.searchhotel.repository.HotelRepository;
import com.mindtree.tripadvisor.searchhotel.service.impl.HotelServiceImpl;


@RunWith(SpringRunner.class)
public class HotelServiceTest {
	@TestConfiguration
	static class UserServiceTestConfiguration {
		@Bean
		public HotelService userService() {
			return new HotelServiceImpl();
			
		}

		@Bean
		public ModelMapper modelMapper() {
			return new ModelMapper();
		}
	}

	@Autowired
	HotelService hotelService;

	@MockBean
	HotelRepository hotelRepository;

	

	@Autowired
	ModelMapper modelMapper;
	
	@Test
	public void getHotel()
	{
		List<Hotel> hotels = new ArrayList<>();
		Hotel hotel = new Hotel();
		hotel.setHotelId(1);
		hotel.setCity("patna");
		hotel.setAddress("budhacolony");
		hotels.add(hotel);
		Mockito.when(hotelRepository.findAllByCity("patna")).thenReturn(hotels);
		assertEquals(hotel.getHotelId(), hotelService.getHotelBasedOnPlace("patna").get(0).getHotelId());
	}
}
