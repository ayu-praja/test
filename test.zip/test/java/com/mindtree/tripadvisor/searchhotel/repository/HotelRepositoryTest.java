package com.mindtree.tripadvisor.searchhotel.repository;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.tripadvisor.TripAdvisorApplication;
import com.mindtree.tripadvisor.searchhotel.entity.Hotel;

@DataJpaTest
@RunWith(SpringRunner.class)
@ContextConfiguration(classes=TripAdvisorApplication.class)
public class HotelRepositoryTest {
	@Autowired
	TestEntityManager entityManager;
	
	@Autowired
	HotelRepository hotelRepository;
	
	@Test
	public void getHotelTest() {

		
		Hotel hotel = new Hotel();
		hotel.setHotelId(9999);
		hotel.setCity("patna");
		hotel.setAddress("budhacolony");
		hotel.setAddress("rr");
		hotel.setArea("we");
		hotel.setCountry("india");
		hotel.setHotelStarRating("good");
		hotel.setLandmark("near ritwik");
		hotel.setHotelFacilities("television|airconsition");
		hotel.setImageUrls("https://www.keysonlinemart.com");
		hotel.setPageurl("https://www.rohankhanna.com");
		hotel.setReviewCount(4);
		
		entityManager.merge(hotel);
		entityManager.flush();
		List<Hotel> hotelfetched=hotelRepository.findAllByCity("patna");
		assertEquals(1, hotelfetched.get(0).getHotelId());
		

	}
}
