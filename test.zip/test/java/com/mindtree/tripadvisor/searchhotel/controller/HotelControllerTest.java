package com.mindtree.tripadvisor.searchhotel.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.mindtree.tripadvisor.TripAdvisorApplication;
import com.mindtree.tripadvisor.searchhotel.entity.Hotel;
import com.mindtree.tripadvisor.searchhotel.service.HotelService;
import com.mindtree.tripadvisor.searchhotel.service.impl.HotelServiceImpl;
import com.mindtree.tripadvisor.userregistration.repository.UserRepository;
import com.mindtree.tripadvisor.userregistration.security.jwt.JwtAuthEntryPoint;
import com.mindtree.tripadvisor.userregistration.security.jwt.JwtProvider;
import com.mindtree.tripadvisor.userregistration.security.services.impl.UserDetailsServiceImpl;

@RunWith(SpringRunner.class)
@WebMvcTest(HotelController.class)

@ContextConfiguration(classes = TripAdvisorApplication.class)
public class HotelControllerTest {
	
	@TestConfiguration
	static class UserServiceTestConfiguration {
		@Bean
		public HotelService hotelService() {
			return new HotelServiceImpl();
		}
		
	

		@Bean
		public ModelMapper modelMapper() {
			return new ModelMapper();
		}
	}
	@MockBean
	UserDetailsServiceImpl userDetailsService;
	
	@MockBean
	private JwtAuthEntryPoint unauthorizedHandler;
	
	@MockBean
	private JwtProvider tokenProvider;
	
	@Autowired
	MockMvc mockMvc;
	@MockBean
	HotelService hotelService;
	
	
	
	
	@Test
	public void hotelTest() throws Exception
	{
		List<Hotel> hotels = new ArrayList<>();
		Hotel hotel = new Hotel();
		hotel.setHotelId(1);
		hotel.setCity("patna");
		hotel.setAddress("budhacolony");
		hotels.add(hotel);
		
		Mockito.when(hotelService.getHotelBasedOnPlace("patna")).thenReturn(hotels);
		mockMvc.perform(get("/gethotelsbasedoncity?place=patna").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
}
