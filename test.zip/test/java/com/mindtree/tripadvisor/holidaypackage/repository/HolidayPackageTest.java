package com.mindtree.tripadvisor.holidaypackage.repository;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.tripadvisor.TripAdvisorApplication;
import com.mindtree.tripadvisor.holidaypackage.dto.HolidayPackageDto;
import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;
import com.mindtree.tripadvisor.holidaypackage.entity.Place;
import com.mindtree.tripadvisor.userregistration.entity.User;

@DataJpaTest
@RunWith(SpringRunner.class)
@ContextConfiguration(classes=TripAdvisorApplication.class)
public class HolidayPackageTest {
	@Autowired
	HolidayPackageRepository holidayPackageRepository;
	
	@Autowired
	TestEntityManager entityManager;
	
	
	ModelMapper modelMapper=new ModelMapper();
	
	@Test
	public void getPackage()
	{
		HolidayPackage holidayPackage=new HolidayPackage();
		holidayPackage.setBudget(700);
		holidayPackage.setDays(5);
		holidayPackage.setPackage_activity("package");
		holidayPackage.setPackage_description("description");
		holidayPackage.setPackage_id(1);
		holidayPackage.setPackage_name("image");
		holidayPackage.setNights(6);
		HolidayPackageDto holidayPackagedto=modelMapper.map(holidayPackage,HolidayPackageDto.class);
		
		String placename="patna";
		Place place=new Place();
		place.setDescription(placename);
		place.setDescription("description");
		place.setPlace_id(1);
		List<User> users=new ArrayList<>();
		User user=new User();
		user.setId((long) 1111111);
		users.add(user);
		
		entityManager.merge(holidayPackage);
		entityManager.flush();
		List<HolidayPackage> holidayPackagelist=holidayPackageRepository.findAll();
		assertEquals(1, holidayPackagelist.get(0).getPackage_id());
		
		
	
	}
}
