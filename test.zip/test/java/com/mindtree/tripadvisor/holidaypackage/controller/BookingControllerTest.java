package com.mindtree.tripadvisor.holidaypackage.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.mindtree.tripadvisor.TripAdvisorApplication;
import com.mindtree.tripadvisor.holidaypackage.dto.HolidayPackageDto;
import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;
import com.mindtree.tripadvisor.holidaypackage.entity.Place;
import com.mindtree.tripadvisor.holidaypackage.service.BookingService;
import com.mindtree.tripadvisor.holidaypackage.service.HolidayPackageService;
import com.mindtree.tripadvisor.holidaypackage.service.PlaceService;
import com.mindtree.tripadvisor.holidaypackage.service.impl.BookingServiceImpl;
import com.mindtree.tripadvisor.holidaypackage.service.impl.HolidayPackageServiceImpl;
import com.mindtree.tripadvisor.holidaypackage.service.impl.PlaceServiceImpl;
import com.mindtree.tripadvisor.userregistration.entity.User;
import com.mindtree.tripadvisor.userregistration.repository.UserRepository;
import com.mindtree.tripadvisor.userregistration.security.jwt.JwtAuthEntryPoint;
import com.mindtree.tripadvisor.userregistration.security.jwt.JwtProvider;
import com.mindtree.tripadvisor.userregistration.security.services.impl.UserDetailsServiceImpl;

@RunWith(SpringRunner.class)
@WebMvcTest(BookingController.class)

@ContextConfiguration(classes = TripAdvisorApplication.class)
public class BookingControllerTest {

	@TestConfiguration
	static class UserServiceTestConfiguration {
		@Bean
		public PlaceService placeServiceImpl() {
			return new PlaceServiceImpl();
		}
		@Bean
		public HolidayPackageService holidayPackageServiceImpl() {
			return new HolidayPackageServiceImpl();
		}
		@Bean
		public BookingService bookingService() {
			return new BookingServiceImpl();
		}

		@Bean
		public ModelMapper modelMapper() {
			return new ModelMapper();
		}
	}

	
	ModelMapper modelMapper=new ModelMapper();
	@MockBean
	UserDetailsServiceImpl userDetailsService;

	@MockBean
	private JwtAuthEntryPoint unauthorizedHandler;

	@MockBean
	private JwtProvider tokenProvider;

	@Autowired
	MockMvc mockMvc;

	@MockBean
	HolidayPackageService holidayPackageService;
	
	@MockBean
	BookingService bookingService;
	
	@MockBean
	UserRepository userRepository;

	@Test
	public void hotelTest() throws Exception {
	String test="ayush";
		

		Mockito.when(bookingService.bookNow("2019-12-30", 1, "ayush")).thenReturn(test);
		mockMvc.perform(get("/bookNow/1/ayush/2019-12-30").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
}

