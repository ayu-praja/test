package com.mindtree.tripadvisor.holidaypackage.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.mindtree.tripadvisor.TripAdvisorApplication;
import com.mindtree.tripadvisor.holidaypackage.dto.PlaceDto;
import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;
import com.mindtree.tripadvisor.holidaypackage.entity.Place;
import com.mindtree.tripadvisor.holidaypackage.service.PlaceService;
import com.mindtree.tripadvisor.holidaypackage.service.impl.PlaceServiceImpl;
import com.mindtree.tripadvisor.searchhotel.controller.HotelController;
import com.mindtree.tripadvisor.searchhotel.entity.Hotel;
import com.mindtree.tripadvisor.searchhotel.service.HotelService;
import com.mindtree.tripadvisor.searchhotel.service.impl.HotelServiceImpl;
import com.mindtree.tripadvisor.userregistration.security.jwt.JwtAuthEntryPoint;
import com.mindtree.tripadvisor.userregistration.security.jwt.JwtProvider;
import com.mindtree.tripadvisor.userregistration.security.services.impl.UserDetailsServiceImpl;

@RunWith(SpringRunner.class)
@WebMvcTest(PlaceController.class)

@ContextConfiguration(classes = TripAdvisorApplication.class)
public class PlaceControllerTest {

	@TestConfiguration
	static class UserServiceTestConfiguration {
		@Bean
		public PlaceService placeServiceImpl() {
			return new PlaceServiceImpl();
		}

		@Bean
		public ModelMapper modelMapper() {
			return new ModelMapper();
		}
	}

	
	ModelMapper modelMapper=new ModelMapper();
	@MockBean
	UserDetailsServiceImpl userDetailsService;

	@MockBean
	private JwtAuthEntryPoint unauthorizedHandler;

	@MockBean
	private JwtProvider tokenProvider;

	@Autowired
	MockMvc mockMvc;

	@MockBean
	PlaceServiceImpl placeServiceImpl;

	@Test
	public void hotelTest() throws Exception {
		Place place = new Place();

		place.setPlace_id(1);
		place.setDestination("patna");
		place.setDescription("place description");
		List<HolidayPackage> holidayPackages = new ArrayList<>();
		HolidayPackage holidayPackage = new HolidayPackage();
		holidayPackage.setBudget(3000);
		holidayPackage.setDays(3);
		holidayPackage.setNights(4);
		holidayPackage.setPackage_activity("1.skuba_driving");
		holidayPackage.setPackage_id(1);
		holidayPackage.setPackage_description("description");
		holidayPackage.setPackage_image("https://www.imagebazzar.com");
		holidayPackage.setPackage_name("package_name");
		holidayPackages.add(holidayPackage);
		PlaceDto placeDto=modelMapper.map(place, PlaceDto.class);
		

		Mockito.when(placeServiceImpl.getPackagesByPlace("patna")).thenReturn(placeDto);
		mockMvc.perform(get("place/getpackage/patna").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
}
