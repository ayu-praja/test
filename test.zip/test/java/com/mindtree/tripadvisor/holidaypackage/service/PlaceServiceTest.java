package com.mindtree.tripadvisor.holidaypackage.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;
import com.mindtree.tripadvisor.holidaypackage.entity.Place;
import com.mindtree.tripadvisor.holidaypackage.exception.PlaceNotFoundException;
import com.mindtree.tripadvisor.holidaypackage.repository.PlaceRepository;
import com.mindtree.tripadvisor.holidaypackage.service.impl.PlaceServiceImpl;
import com.mindtree.tripadvisor.searchhotel.repository.HotelRepository;
import com.mindtree.tripadvisor.searchhotel.service.HotelService;
import com.mindtree.tripadvisor.searchhotel.service.impl.HotelServiceImpl;

@RunWith(SpringRunner.class)
public class PlaceServiceTest {
	@TestConfiguration
	static class UserServiceTestConfiguration {
		@Bean
		public PlaceService placeService() {
			return new PlaceServiceImpl();
			
		}

		@Bean
		public ModelMapper modelMapper() {
			return new ModelMapper();
		}
	}
	
	
	@Autowired
	PlaceService placeService;

	@MockBean
	PlaceRepository placeRepository;

	@Autowired
	ModelMapper modelMapper;
	String placeName="patna";
	
	@Test
	public void placeTest() throws PlaceNotFoundException
	{
		Place place=new Place();
		
		place.setPlace_id(1);
	place.setDestination("patna");
		place.setDescription("place description");
		List<HolidayPackage> holidayPackages=new ArrayList<>();
		HolidayPackage holidayPackage=new HolidayPackage();
		holidayPackage.setBudget(3000);
		holidayPackage.setDays(3);
		holidayPackage.setNights(4);
		holidayPackage.setPackage_activity("1.skuba_driving");
		holidayPackage.setPackage_id(1);
		holidayPackage.setPackage_description("description");
		holidayPackage.setPackage_image("https://www.imagebazzar.com");
		holidayPackage.setPackage_name("package_name");
		holidayPackages.add(holidayPackage);
		Mockito.when(placeRepository.findByDestinationIgnoreCase(placeName)).thenReturn(Optional.of(place));
		assertEquals(place.getPlace_id(), placeService.getPackagesByPlace("patna").getPlace_id());
	}
}
