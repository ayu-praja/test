package com.mindtree.tripadvisor.holidaypackage.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;


import com.mindtree.tripadvisor.holidaypackage.dto.HolidayPackageDto;
import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;
import com.mindtree.tripadvisor.holidaypackage.entity.Place;
import com.mindtree.tripadvisor.holidaypackage.exception.PlaceNotFoundException;
import com.mindtree.tripadvisor.holidaypackage.repository.HolidayPackageRepository;
import com.mindtree.tripadvisor.holidaypackage.repository.PlaceRepository;
import com.mindtree.tripadvisor.holidaypackage.service.impl.HolidayPackageServiceImpl;
import com.mindtree.tripadvisor.holidaypackage.service.impl.PlaceServiceImpl;
import com.mindtree.tripadvisor.userregistration.entity.User;
import com.mindtree.tripadvisor.userregistration.repository.UserRepository;

@RunWith(SpringRunner.class)
public class HolidayPackageServiceTestImpl {
	@TestConfiguration
	static class UserServiceTestConfiguration {
		@Bean
		public HolidayPackageService placeService() {
			return new HolidayPackageServiceImpl();
			
		}

		@Bean
		public ModelMapper modelMapper() {
			return new ModelMapper();
		}
	}
	
	
	@Autowired
	HolidayPackageService holidayPackageService;

	@MockBean
	HolidayPackageRepository holidayPackageRepository;
	
	@MockBean
	PlaceRepository placeRepository;
	
	@MockBean
	UserRepository userRepository;

	@Autowired
	ModelMapper model;
	
	@Test
	public void addPackage() throws PlaceNotFoundException
	{
		HolidayPackage holidayPackage=new HolidayPackage();
		holidayPackage.setBudget(700);
		holidayPackage.setDays(5);
		holidayPackage.setPackage_activity("package");
		holidayPackage.setPackage_description("description");
		holidayPackage.setPackage_id(1);
		holidayPackage.setPackage_name("image");
		holidayPackage.setNights(6);
		HolidayPackageDto holidayPackagedto=model.map(holidayPackage,HolidayPackageDto.class);
		
		String placename="patna";
		Place place=new Place();
		place.setDescription(placename);
		place.setDescription("description");
		place.setPlace_id(1);
		List<User> users=new ArrayList<>();
		User user=new User();
		user.setId((long) 1111111);
		users.add(user);

		Mockito.when(placeRepository.findByDestinationIgnoreCase(placename)).thenReturn(Optional.of(place));
		
		Mockito.when(holidayPackageRepository.save(holidayPackage)).thenReturn(holidayPackage);
		Mockito.when(userRepository.findAll()).thenReturn(users);

		
		
		
		
		
		
	}
}
