package com.mindtree.tripadvisor.holidaypackage.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.tripadvisor.holidaypackage.entity.Booking;
import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;
import com.mindtree.tripadvisor.holidaypackage.entity.Place;
import com.mindtree.tripadvisor.holidaypackage.exception.PlaceNotFoundException;
import com.mindtree.tripadvisor.holidaypackage.repository.BookingRepository;
import com.mindtree.tripadvisor.holidaypackage.repository.HolidayPackageRepository;
import com.mindtree.tripadvisor.holidaypackage.repository.PlaceRepository;
import com.mindtree.tripadvisor.holidaypackage.service.impl.BookingServiceImpl;
import com.mindtree.tripadvisor.holidaypackage.service.impl.PlaceServiceImpl;
import com.mindtree.tripadvisor.userregistration.entity.User;
import com.mindtree.tripadvisor.userregistration.repository.UserRepository;

@RunWith(SpringRunner.class)
public class BookingServiceTest {
	@TestConfiguration
	static class UserServiceTestConfiguration {
		@Bean
		public BookingService bookingService() {
			return new BookingServiceImpl();

		}

		@Bean
		public ModelMapper modelMapper() {
			return new ModelMapper();
		}
	}

	@Autowired
	BookingService bookingService;

	@MockBean
	BookingRepository bookingRepository;

	@MockBean
	HolidayPackageRepository holidayPackageRepository;

	@MockBean
	UserRepository userRepository;

	@Autowired
	ModelMapper modelMapper;

	String userName = "ayushthe";

	User user = new User();
	HolidayPackage holidayPackage = new HolidayPackage();

	@Before
	public void setup() {
		user.setEmail("ayus.praj@gmail.com");
		user.setId(1L);
		user.setName("ayush");
		user.setPassword("ayush");
		user.setUsername(userName);

		holidayPackage.setBudget(700);
		holidayPackage.setDays(5);
		holidayPackage.setPackage_activity("package");
		holidayPackage.setPackage_description("description");
		holidayPackage.setPackage_id(1);
		holidayPackage.setPackage_name("image");
		holidayPackage.setNights(6);

	}

	@Test
	public void placeTest() throws PlaceNotFoundException {
		System.out.println(user);
		Booking booking = new Booking(holidayPackage, user, "2019-12-12");
		List<Booking> bookings = new ArrayList<>();
		bookings.add(booking);

		Mockito.when(bookingRepository.save(booking)).thenReturn(booking);
		Mockito.when(holidayPackageRepository.findById(1)).thenReturn(Optional.of(holidayPackage));
		Mockito.when(userRepository.findByUsername(userName)).thenReturn(Optional.of(user));
		assertEquals("Booking Unsucessfully", bookingService.bookNow("2019-12-12", 1, userName));
	}
}
